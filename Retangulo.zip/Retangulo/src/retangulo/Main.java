package retangulo;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!\n");
        Retangulo valor=new Retangulo (0.0, 0.0);
        Scanner entrada=new Scanner (System.in);
        System.out.printf ("Digite o valor da base: \n");
        valor.base = entrada.nextDouble();
        System.out.printf ("Digite o valor da altura: \n");
        valor.altura = entrada.nextDouble();
        valor.perimetro();
        valor.area();
    }
    
}
