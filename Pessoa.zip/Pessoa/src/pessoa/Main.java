package pessoa;
import java.util.Scanner;
import java.util.GregorianCalendar;
import java.util.Calendar;

public class Main {
    
    public static void main(String[] args) {
        
        System.out.println("Hello, World!");
        
        Pessoa valor=new Pessoa("Joao", 0, 0, 0, 0, 0);
        Scanner entrada=new Scanner(System.in);
        Data val=new Data(0, 0, 0);
        System.out.printf ("Qual o nome da pessoa?");
        String nome = entrada.nextLine();
        System.out.printf ("Qual a altura em cm dessa pessoa?");
        valor.altura=entrada.nextInt();
        
        System.out.printf ("Que dia nasceu?");
        valor.diaN=entrada.nextInt();
        System.out.printf("Qual o mês do nascimento?");
        valor.mesN=entrada.nextInt();
        System.out.printf ("Que ano nasceu?");
        valor.anoN=entrada.nextInt();
        
        
        Calendar cal = GregorianCalendar.getInstance();
        val.dia = cal.get(Calendar.DAY_OF_MONTH);
        val.mes = cal.get(Calendar.MONTH) + 1;
        val.ano = cal.get(Calendar.YEAR);
        
        System.out.printf ("Hoje é: %d/%d/%d.\n", val.dia, val.mes, val.ano);
        
        valor.idade=val.ano-valor.anoN;
        
        System.out.printf ("\n%.5s, mede %dcm e tem %d anos.", valor.nome, valor.altura, valor.idade);
        
        System.out.printf ("\n Usando toString na classe: \n\n");
        
        Pessoa P = new Pessoa ("Jose", 178, 01, 04, 1999, 23);
        System.out.printf("%s \n", P);
        
    
    }
    
}
