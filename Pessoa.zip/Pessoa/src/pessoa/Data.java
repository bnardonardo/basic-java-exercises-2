package pessoa;
import java.util.GregorianCalendar;
import java.util.Calendar;

public class Data {
    public int dia;
    public int mes;
    public int ano;
    
    public Data (){
        dia=0;
        mes=0;
        ano=0;
    }
    
    public Data (int dia, int mes, int ano){
        this.dia=dia;
        this.mes=mes;
        this.ano=ano;
    }
}
