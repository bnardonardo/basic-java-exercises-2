package pessoa;
import java.util.Date;

public class Pessoa {
    public String nome;
    public int altura;
    public int idade;
    public int diaN;
    public int mesN;
    public int anoN;
    
    public Pessoa (){
        altura=0;
        diaN=0;
        mesN=0;
        anoN=0;
        idade=0;
    }

    public Pessoa (String nome, int altura, int diaN, int mesN, int anoN, int idade){
      this.nome=nome;
      this.altura=altura;
        this.diaN=diaN;
        this.mesN=mesN;
        this.anoN=anoN;
        this.idade=idade;
    }
     
   @Override
     public String toString(){
       return String.format ("%s mede %d cm e tem %d anos.", nome, altura, idade);
      
   }
}
