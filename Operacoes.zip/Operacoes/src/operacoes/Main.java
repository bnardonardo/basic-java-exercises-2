
package operacoes;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!\n");
        Operacoes valor=new Operacoes (0.0, 0.0);
        Scanner entrada=new Scanner (System.in);
        System.out.printf ("Digite o primeiro valor: \n");
        valor.a = entrada.nextDouble();
        System.out.printf ("Digite o segundo valor: \n");
        valor.b = entrada.nextDouble();
        valor.Soma();
        valor.Subtracao();
        valor.Multiplicacao();
        valor.Divisao();
    }
    
}
