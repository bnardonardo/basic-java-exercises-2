package operacoes;

public class Operacoes {
    public double a;
    public double b;
    public double soma;
    public double sub;
    public double multi;
    public double divi;
    
    public Operacoes (){
        a=0.0;
        b=0.0;
    }
    
    public Operacoes (double a, double b){
        this.a=a;
        this.b=b;
    }
    
    public void Soma(){
        soma = a+b;
        System.out.printf("\n%.2f + %.2f = %.2f\n", a, b, soma);
    }
    public void Subtracao(){
        sub = a-b;
        System.out.printf("\n%.2f - %.2f = %.2f\n", a, b, sub);
    }
    
    public void Multiplicacao(){
        multi = a*b;
        System.out.printf("\n%.2f X %.2f = %.2f\n", a, b, multi);
				}
    public void Divisao(){
        divi = a/b;
        System.out.printf("\n%.2f / %.2f = %.2f\n", a, b, divi);
    }
}