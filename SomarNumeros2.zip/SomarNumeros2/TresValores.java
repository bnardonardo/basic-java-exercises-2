package somarnumeros2;

public class TresValores {
    double a;
    double b;
    double c;
    /*public static void main(String[] args) {
        System.out.println("Hello, World!");*
}*/
    
}
