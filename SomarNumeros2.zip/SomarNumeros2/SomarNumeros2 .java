package somarnumeros2;
import java.util.Scanner;

public class SomarNumeros2 {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
    
}
