package somarnumeros2;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        TresValores valor=new TresValores (0.0, 0.0, 0.0);
        Scanner entrada=new Scanner (System.in);
        System.out.printf ("Digite o primeiro valor: ");
        valor.a=entrada.nextDouble();
        System.out.printf ("Digite o segundo valor: ");
        valor.b=entrada.nextDouble();
        valor.c=valor.a+valor.b; 
        valor.soma();
        System.out.printf ("\n A soma de %.2f mais %.2f é: %.2f\n",valor.a, valor.b, valor.c);
        
    }
    
}
