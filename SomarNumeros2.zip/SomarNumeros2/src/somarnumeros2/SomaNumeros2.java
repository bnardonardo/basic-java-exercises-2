package somarnumeros2;
import java.util.Scanner;

public class SomaNumeros2 {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        TresValores valor=new TresValores ();
        Scanner entrada=new Scanner (System.in);
        System.out.printf ("Digite o primeiro valor: ");
        valor.a=entrada.nextDouble();
        System.out.printf ("Digite o segundo valor: ");
        valor.b=entrada.nextDouble();
        valor.c=valor.a+valor.b;
        System.out.printf ("A soma de %f mais %f é: %f",valor.a, valor.b, valor.c);
    }
    
}
