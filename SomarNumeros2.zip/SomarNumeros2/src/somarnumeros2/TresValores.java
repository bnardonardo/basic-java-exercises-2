package somarnumeros2;

public class TresValores {
    public double a;
    public double b;
    public double c;
    
    public TresValores (){
        a=0.0;
        b=0.0;
        c=0.0;
    }
    
    public TresValores (double a, double b, double c){
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public void soma(){
    c=a+b;
        System.out.printf ("Usando um método dentro da classe: %.2f\n", c);
    }
    
    /*public static void main(String[] args) {
        System.out.println("Hello, World!");*
}*/
    
}
