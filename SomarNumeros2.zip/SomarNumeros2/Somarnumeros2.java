package somarnumeros2;
import java.util.Scanner;

public class Somarnumeros2 {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        TresValores valor=new TresValores ();
        Scanner entrada=new Scanner (System.in);
        
    }
    
}
